﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using EntityClass;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityClass.Tests
{
    using System.Collections;
    [TestClass()]
    public class ProjectTests
    {
        [TestMethod()]
        public void ProjectTest()
        {
            ArrayList proArrayList = new ArrayList();
            //生成数组
            for (int i = 0; i < 5; i++)
            {
                proArrayList.Add(new Project(i + 1000));
            }
            Project a;
            for (int i = 0; i < 5; i++)
            {
                 a = (Project)proArrayList[i];
                Assert.AreEqual(i+1000, a.intId);
            }
            

           // Assert.Fail();
        }
        
    }
}