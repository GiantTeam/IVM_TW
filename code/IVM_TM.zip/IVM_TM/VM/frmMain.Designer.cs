﻿
namespace VM
{
    partial class frmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            this.picLogo2 = new System.Windows.Forms.PictureBox();
            this.picLogo1 = new System.Windows.Forms.PictureBox();
            this.tmrRushReflash = new System.Windows.Forms.Timer(this.components);
            this.tapRush = new System.Windows.Forms.TabPage();
            this.grpRush = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btnRConfirm = new System.Windows.Forms.Button();
            this.btnActionRush = new System.Windows.Forms.Button();
            this.grpRRate = new System.Windows.Forms.GroupBox();
            this.lblRRateHigh = new System.Windows.Forms.Label();
            this.txtRRateHigh = new System.Windows.Forms.TextBox();
            this.lblRRateLow = new System.Windows.Forms.Label();
            this.txtRRateLow = new System.Windows.Forms.TextBox();
            this.rdoRRate4 = new System.Windows.Forms.RadioButton();
            this.rdoRRate3 = new System.Windows.Forms.RadioButton();
            this.rdoRRate2 = new System.Windows.Forms.RadioButton();
            this.rdoRRate1 = new System.Windows.Forms.RadioButton();
            this.grpRMoney = new System.Windows.Forms.GroupBox();
            this.lblRMoneyHigh = new System.Windows.Forms.Label();
            this.txtRMoneyHigh = new System.Windows.Forms.TextBox();
            this.lblRMoneyLow = new System.Windows.Forms.Label();
            this.txtRMoneyLow = new System.Windows.Forms.TextBox();
            this.rdoRMoney4 = new System.Windows.Forms.RadioButton();
            this.rdoRMoney3 = new System.Windows.Forms.RadioButton();
            this.rdoRMoney2 = new System.Windows.Forms.RadioButton();
            this.rdoRMoney1 = new System.Windows.Forms.RadioButton();
            this.lblRRate = new System.Windows.Forms.Label();
            this.lblRMoney = new System.Windows.Forms.Label();
            this.lblRTime = new System.Windows.Forms.Label();
            this.grpRTime = new System.Windows.Forms.GroupBox();
            this.lblRTimeHigh = new System.Windows.Forms.Label();
            this.txtRTimeHigh = new System.Windows.Forms.TextBox();
            this.lblRTimeLow = new System.Windows.Forms.Label();
            this.txtRTimeLow = new System.Windows.Forms.TextBox();
            this.rdoRTime4 = new System.Windows.Forms.RadioButton();
            this.rdoRTime3 = new System.Windows.Forms.RadioButton();
            this.rdoRTime2 = new System.Windows.Forms.RadioButton();
            this.rdoRTime1 = new System.Windows.Forms.RadioButton();
            this.tapAnalyse = new System.Windows.Forms.TabPage();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.grpStatisticTable = new System.Windows.Forms.DataGridView();
            this.mmuStatistic = new System.Windows.Forms.MenuStrip();
            this.mmuNew = new System.Windows.Forms.ToolStripMenuItem();
            this.mmuSave = new System.Windows.Forms.ToolStripMenuItem();
            this.mmuEmpty = new System.Windows.Forms.ToolStripMenuItem();
            this.mmuImport = new System.Windows.Forms.ToolStripMenuItem();
            this.mmuExport = new System.Windows.Forms.ToolStripMenuItem();
            this.mmuChart = new System.Windows.Forms.ToolStripMenuItem();
            this.tapSearch = new System.Windows.Forms.TabPage();
            this.lblShowPg = new System.Windows.Forms.Label();
            this.btnToRecord = new System.Windows.Forms.Button();
            this.btnRateConfirm = new System.Windows.Forms.Button();
            this.btnTimeConfirm = new System.Windows.Forms.Button();
            this.btnPageDown = new System.Windows.Forms.Button();
            this.btnPageUp = new System.Windows.Forms.Button();
            this.grpSearch = new System.Windows.Forms.DataGridView();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.time = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.money = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inverst = new System.Windows.Forms.DataGridViewButtonColumn();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnRush = new System.Windows.Forms.Button();
            this.btnMoneyConfirm = new System.Windows.Forms.Button();
            this.lblSplit = new System.Windows.Forms.Label();
            this.grpSRate = new System.Windows.Forms.GroupBox();
            this.rdoRateAll = new System.Windows.Forms.RadioButton();
            this.lblSRateHigh = new System.Windows.Forms.Label();
            this.txtSRateHigh = new System.Windows.Forms.TextBox();
            this.lblSRateLow = new System.Windows.Forms.Label();
            this.txtSRateLow = new System.Windows.Forms.TextBox();
            this.rdoSRate4 = new System.Windows.Forms.RadioButton();
            this.rdoSRate3 = new System.Windows.Forms.RadioButton();
            this.rdoSRate2 = new System.Windows.Forms.RadioButton();
            this.rdoSRate1 = new System.Windows.Forms.RadioButton();
            this.grpSMoney = new System.Windows.Forms.GroupBox();
            this.rdoMoneyAll = new System.Windows.Forms.RadioButton();
            this.lblSMoneyHigh = new System.Windows.Forms.Label();
            this.txtSMoneyHigh = new System.Windows.Forms.TextBox();
            this.lblSMoneyLow = new System.Windows.Forms.Label();
            this.txtSMoneyLow = new System.Windows.Forms.TextBox();
            this.rdoSMoney4 = new System.Windows.Forms.RadioButton();
            this.rdoSMoney3 = new System.Windows.Forms.RadioButton();
            this.rdoSMoney2 = new System.Windows.Forms.RadioButton();
            this.rdoSMoney1 = new System.Windows.Forms.RadioButton();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblSRate = new System.Windows.Forms.Label();
            this.lblSMoney = new System.Windows.Forms.Label();
            this.lblSTime = new System.Windows.Forms.Label();
            this.grpSTime = new System.Windows.Forms.GroupBox();
            this.rdoTimeAll = new System.Windows.Forms.RadioButton();
            this.lblSTimeHigh = new System.Windows.Forms.Label();
            this.txtSTimeHigh = new System.Windows.Forms.TextBox();
            this.lblSTimeLow = new System.Windows.Forms.Label();
            this.txtSTimeLow = new System.Windows.Forms.TextBox();
            this.rdoSTime4 = new System.Windows.Forms.RadioButton();
            this.rdoSTime3 = new System.Windows.Forms.RadioButton();
            this.rdoSTime2 = new System.Windows.Forms.RadioButton();
            this.rdoSTime1 = new System.Windows.Forms.RadioButton();
            this.grpSort = new System.Windows.Forms.GroupBox();
            this.rdoSortRate = new System.Windows.Forms.RadioButton();
            this.rdoSortMoney = new System.Windows.Forms.RadioButton();
            this.rdoSortTime = new System.Windows.Forms.RadioButton();
            this.rdoSortDefault = new System.Windows.Forms.RadioButton();
            this.grpSortMode = new System.Windows.Forms.GroupBox();
            this.rdoSortDown = new System.Windows.Forms.RadioButton();
            this.rdoSortUp = new System.Windows.Forms.RadioButton();
            this.tabSelectModule = new System.Windows.Forms.TabControl();
            this.ColumnTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMoney = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Other = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo1)).BeginInit();
            this.tapRush.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grpRush)).BeginInit();
            this.grpRRate.SuspendLayout();
            this.grpRMoney.SuspendLayout();
            this.grpRTime.SuspendLayout();
            this.tapAnalyse.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grpStatisticTable)).BeginInit();
            this.mmuStatistic.SuspendLayout();
            this.tapSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grpSearch)).BeginInit();
            this.grpSRate.SuspendLayout();
            this.grpSMoney.SuspendLayout();
            this.grpSTime.SuspendLayout();
            this.grpSort.SuspendLayout();
            this.grpSortMode.SuspendLayout();
            this.tabSelectModule.SuspendLayout();
            this.SuspendLayout();
            // 
            // picLogo2
            // 
            this.picLogo2.Image = global::VM.Properties.Resources.无标题1;
            this.picLogo2.Location = new System.Drawing.Point(160, 24);
            this.picLogo2.Name = "picLogo2";
            this.picLogo2.Size = new System.Drawing.Size(640, 72);
            this.picLogo2.TabIndex = 3;
            this.picLogo2.TabStop = false;
            // 
            // picLogo1
            // 
            this.picLogo1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("picLogo1.ErrorImage")));
            this.picLogo1.Image = global::VM.Properties.Resources.无标题;
            this.picLogo1.Location = new System.Drawing.Point(0, 0);
            this.picLogo1.Name = "picLogo1";
            this.picLogo1.Size = new System.Drawing.Size(136, 120);
            this.picLogo1.TabIndex = 2;
            this.picLogo1.TabStop = false;
            // 
            // tmrRushReflash
            // 
            this.tmrRushReflash.Interval = 10000;
            this.tmrRushReflash.Tick += new System.EventHandler(this.tmrRushReflash_Tick);
            // 
            // tapRush
            // 
            this.tapRush.Controls.Add(this.grpRush);
            this.tapRush.Controls.Add(this.btnRConfirm);
            this.tapRush.Controls.Add(this.btnActionRush);
            this.tapRush.Controls.Add(this.grpRRate);
            this.tapRush.Controls.Add(this.grpRMoney);
            this.tapRush.Controls.Add(this.lblRRate);
            this.tapRush.Controls.Add(this.lblRMoney);
            this.tapRush.Controls.Add(this.lblRTime);
            this.tapRush.Controls.Add(this.grpRTime);
            this.tapRush.Location = new System.Drawing.Point(4, 30);
            this.tapRush.Name = "tapRush";
            this.tapRush.Size = new System.Drawing.Size(896, 580);
            this.tapRush.TabIndex = 2;
            this.tapRush.Text = "抢购";
            this.tapRush.UseVisualStyleBackColor = true;
            // 
            // grpRush
            // 
            this.grpRush.AllowUserToAddRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter;
            this.grpRush.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.grpRush.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grpRush.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grpRush.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.grpRush.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedVertical;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grpRush.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.grpRush.ColumnHeadersHeight = 30;
            this.grpRush.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewButtonColumn1});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grpRush.DefaultCellStyle = dataGridViewCellStyle3;
            this.grpRush.Location = new System.Drawing.Point(8, 264);
            this.grpRush.Name = "grpRush";
            this.grpRush.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grpRush.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.grpRush.RowHeadersVisible = false;
            this.grpRush.RowHeadersWidth = 100;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.grpRush.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.grpRush.RowTemplate.Height = 23;
            this.grpRush.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.grpRush.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.grpRush.Size = new System.Drawing.Size(864, 264);
            this.grpRush.TabIndex = 22;
            this.grpRush.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grpRush_CellContentClick);
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn7.DataPropertyName = "name";
            this.dataGridViewTextBoxColumn7.HeaderText = "项目";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn8.DataPropertyName = "time";
            this.dataGridViewTextBoxColumn8.HeaderText = "投资期限";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn9.DataPropertyName = "money";
            this.dataGridViewTextBoxColumn9.HeaderText = "起投金额";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn10.DataPropertyName = "rate";
            this.dataGridViewTextBoxColumn10.HeaderText = "收益率";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewButtonColumn1
            // 
            this.dataGridViewButtonColumn1.HeaderText = "投资";
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            // 
            // btnRConfirm
            // 
            this.btnRConfirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRConfirm.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnRConfirm.Location = new System.Drawing.Point(784, 216);
            this.btnRConfirm.Name = "btnRConfirm";
            this.btnRConfirm.Size = new System.Drawing.Size(75, 32);
            this.btnRConfirm.TabIndex = 19;
            this.btnRConfirm.Text = "确定";
            this.btnRConfirm.UseVisualStyleBackColor = true;
            this.btnRConfirm.Click += new System.EventHandler(this.btnRConfirm_Click);
            // 
            // btnActionRush
            // 
            this.btnActionRush.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnActionRush.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnActionRush.Location = new System.Drawing.Point(336, 24);
            this.btnActionRush.Name = "btnActionRush";
            this.btnActionRush.Size = new System.Drawing.Size(136, 40);
            this.btnActionRush.TabIndex = 18;
            this.btnActionRush.Text = "开始抢购";
            this.btnActionRush.UseVisualStyleBackColor = true;
            this.btnActionRush.Click += new System.EventHandler(this.btnActionRush_Click);
            // 
            // grpRRate
            // 
            this.grpRRate.Controls.Add(this.lblRRateHigh);
            this.grpRRate.Controls.Add(this.txtRRateHigh);
            this.grpRRate.Controls.Add(this.lblRRateLow);
            this.grpRRate.Controls.Add(this.txtRRateLow);
            this.grpRRate.Controls.Add(this.rdoRRate4);
            this.grpRRate.Controls.Add(this.rdoRRate3);
            this.grpRRate.Controls.Add(this.rdoRRate2);
            this.grpRRate.Controls.Add(this.rdoRRate1);
            this.grpRRate.Location = new System.Drawing.Point(144, 184);
            this.grpRRate.Name = "grpRRate";
            this.grpRRate.Size = new System.Drawing.Size(616, 48);
            this.grpRRate.TabIndex = 17;
            this.grpRRate.TabStop = false;
            // 
            // lblRRateHigh
            // 
            this.lblRRateHigh.AutoSize = true;
            this.lblRRateHigh.Enabled = false;
            this.lblRRateHigh.Location = new System.Drawing.Point(576, 24);
            this.lblRRateHigh.Name = "lblRRateHigh";
            this.lblRRateHigh.Size = new System.Drawing.Size(24, 21);
            this.lblRRateHigh.TabIndex = 8;
            this.lblRRateHigh.Text = "%";
            // 
            // txtRRateHigh
            // 
            this.txtRRateHigh.Enabled = false;
            this.txtRRateHigh.Location = new System.Drawing.Point(504, 16);
            this.txtRRateHigh.Name = "txtRRateHigh";
            this.txtRRateHigh.Size = new System.Drawing.Size(56, 29);
            this.txtRRateHigh.TabIndex = 7;
            // 
            // lblRRateLow
            // 
            this.lblRRateLow.AutoSize = true;
            this.lblRRateLow.Enabled = false;
            this.lblRRateLow.Location = new System.Drawing.Point(440, 24);
            this.lblRRateLow.Name = "lblRRateLow";
            this.lblRRateLow.Size = new System.Drawing.Size(36, 21);
            this.lblRRateLow.TabIndex = 6;
            this.lblRRateLow.Text = "%~";
            // 
            // txtRRateLow
            // 
            this.txtRRateLow.Enabled = false;
            this.txtRRateLow.Location = new System.Drawing.Point(376, 16);
            this.txtRRateLow.Name = "txtRRateLow";
            this.txtRRateLow.Size = new System.Drawing.Size(64, 29);
            this.txtRRateLow.TabIndex = 4;
            // 
            // rdoRRate4
            // 
            this.rdoRRate4.AutoSize = true;
            this.rdoRRate4.Location = new System.Drawing.Point(320, 16);
            this.rdoRRate4.Name = "rdoRRate4";
            this.rdoRRate4.Size = new System.Drawing.Size(60, 25);
            this.rdoRRate4.TabIndex = 3;
            this.rdoRRate4.Tag = "0";
            this.rdoRRate4.Text = "其它";
            this.rdoRRate4.UseVisualStyleBackColor = true;
            this.rdoRRate4.CheckedChanged += new System.EventHandler(this.rdoRRate4_CheckedChanged);
            // 
            // rdoRRate3
            // 
            this.rdoRRate3.AutoSize = true;
            this.rdoRRate3.Location = new System.Drawing.Point(208, 16);
            this.rdoRRate3.Name = "rdoRRate3";
            this.rdoRRate3.Size = new System.Drawing.Size(92, 25);
            this.rdoRRate3.TabIndex = 2;
            this.rdoRRate3.Tag = "1";
            this.rdoRRate3.Text = "10%以上";
            this.rdoRRate3.UseVisualStyleBackColor = true;
            this.rdoRRate3.CheckedChanged += new System.EventHandler(this.rdoRRate3_CheckedChanged);
            // 
            // rdoRRate2
            // 
            this.rdoRRate2.AutoSize = true;
            this.rdoRRate2.Location = new System.Drawing.Point(104, 16);
            this.rdoRRate2.Name = "rdoRRate2";
            this.rdoRRate2.Size = new System.Drawing.Size(90, 25);
            this.rdoRRate2.TabIndex = 1;
            this.rdoRRate2.Tag = "2";
            this.rdoRRate2.Text = "5%-10%";
            this.rdoRRate2.UseVisualStyleBackColor = true;
            this.rdoRRate2.CheckedChanged += new System.EventHandler(this.rdoRRate2_CheckedChanged);
            // 
            // rdoRRate1
            // 
            this.rdoRRate1.AutoSize = true;
            this.rdoRRate1.Location = new System.Drawing.Point(0, 16);
            this.rdoRRate1.Name = "rdoRRate1";
            this.rdoRRate1.Size = new System.Drawing.Size(83, 25);
            this.rdoRRate1.TabIndex = 0;
            this.rdoRRate1.Tag = "3";
            this.rdoRRate1.Text = "5%以下";
            this.rdoRRate1.UseVisualStyleBackColor = true;
            this.rdoRRate1.CheckedChanged += new System.EventHandler(this.rdoRRate1_CheckedChanged);
            // 
            // grpRMoney
            // 
            this.grpRMoney.Controls.Add(this.lblRMoneyHigh);
            this.grpRMoney.Controls.Add(this.txtRMoneyHigh);
            this.grpRMoney.Controls.Add(this.lblRMoneyLow);
            this.grpRMoney.Controls.Add(this.txtRMoneyLow);
            this.grpRMoney.Controls.Add(this.rdoRMoney4);
            this.grpRMoney.Controls.Add(this.rdoRMoney3);
            this.grpRMoney.Controls.Add(this.rdoRMoney2);
            this.grpRMoney.Controls.Add(this.rdoRMoney1);
            this.grpRMoney.Location = new System.Drawing.Point(144, 136);
            this.grpRMoney.Name = "grpRMoney";
            this.grpRMoney.Size = new System.Drawing.Size(616, 56);
            this.grpRMoney.TabIndex = 16;
            this.grpRMoney.TabStop = false;
            // 
            // lblRMoneyHigh
            // 
            this.lblRMoneyHigh.AutoSize = true;
            this.lblRMoneyHigh.Enabled = false;
            this.lblRMoneyHigh.Location = new System.Drawing.Point(576, 24);
            this.lblRMoneyHigh.Name = "lblRMoneyHigh";
            this.lblRMoneyHigh.Size = new System.Drawing.Size(26, 21);
            this.lblRMoneyHigh.TabIndex = 8;
            this.lblRMoneyHigh.Text = "万";
            // 
            // txtRMoneyHigh
            // 
            this.txtRMoneyHigh.Enabled = false;
            this.txtRMoneyHigh.Location = new System.Drawing.Point(504, 16);
            this.txtRMoneyHigh.Name = "txtRMoneyHigh";
            this.txtRMoneyHigh.Size = new System.Drawing.Size(56, 29);
            this.txtRMoneyHigh.TabIndex = 7;
            // 
            // lblRMoneyLow
            // 
            this.lblRMoneyLow.AutoSize = true;
            this.lblRMoneyLow.Enabled = false;
            this.lblRMoneyLow.Location = new System.Drawing.Point(440, 24);
            this.lblRMoneyLow.Name = "lblRMoneyLow";
            this.lblRMoneyLow.Size = new System.Drawing.Size(38, 21);
            this.lblRMoneyLow.TabIndex = 6;
            this.lblRMoneyLow.Text = "万~";
            // 
            // txtRMoneyLow
            // 
            this.txtRMoneyLow.Enabled = false;
            this.txtRMoneyLow.Location = new System.Drawing.Point(376, 16);
            this.txtRMoneyLow.Name = "txtRMoneyLow";
            this.txtRMoneyLow.Size = new System.Drawing.Size(64, 29);
            this.txtRMoneyLow.TabIndex = 4;
            // 
            // rdoRMoney4
            // 
            this.rdoRMoney4.AutoSize = true;
            this.rdoRMoney4.Location = new System.Drawing.Point(320, 16);
            this.rdoRMoney4.Name = "rdoRMoney4";
            this.rdoRMoney4.Size = new System.Drawing.Size(60, 25);
            this.rdoRMoney4.TabIndex = 3;
            this.rdoRMoney4.Tag = "0";
            this.rdoRMoney4.Text = "其它";
            this.rdoRMoney4.UseVisualStyleBackColor = true;
            this.rdoRMoney4.CheckedChanged += new System.EventHandler(this.rdoRMoney4_CheckedChanged);
            // 
            // rdoRMoney3
            // 
            this.rdoRMoney3.AutoSize = true;
            this.rdoRMoney3.Location = new System.Drawing.Point(208, 16);
            this.rdoRMoney3.Name = "rdoRMoney3";
            this.rdoRMoney3.Size = new System.Drawing.Size(78, 25);
            this.rdoRMoney3.TabIndex = 2;
            this.rdoRMoney3.Tag = "1";
            this.rdoRMoney3.Text = "5-10万";
            this.rdoRMoney3.UseVisualStyleBackColor = true;
            this.rdoRMoney3.CheckedChanged += new System.EventHandler(this.rdoRMoney3_CheckedChanged);
            // 
            // rdoRMoney2
            // 
            this.rdoRMoney2.AutoSize = true;
            this.rdoRMoney2.Location = new System.Drawing.Point(96, 16);
            this.rdoRMoney2.Name = "rdoRMoney2";
            this.rdoRMoney2.Size = new System.Drawing.Size(69, 25);
            this.rdoRMoney2.TabIndex = 1;
            this.rdoRMoney2.Tag = "2";
            this.rdoRMoney2.Text = "1-5万";
            this.rdoRMoney2.UseVisualStyleBackColor = true;
            this.rdoRMoney2.CheckedChanged += new System.EventHandler(this.rdoRMoney2_CheckedChanged);
            // 
            // rdoRMoney1
            // 
            this.rdoRMoney1.AutoSize = true;
            this.rdoRMoney1.Location = new System.Drawing.Point(0, 16);
            this.rdoRMoney1.Name = "rdoRMoney1";
            this.rdoRMoney1.Size = new System.Drawing.Size(85, 25);
            this.rdoRMoney1.TabIndex = 0;
            this.rdoRMoney1.Tag = "3";
            this.rdoRMoney1.Text = "1万以下";
            this.rdoRMoney1.UseVisualStyleBackColor = true;
            this.rdoRMoney1.CheckedChanged += new System.EventHandler(this.rdoRMoney1_CheckedChanged);
            // 
            // lblRRate
            // 
            this.lblRRate.AutoSize = true;
            this.lblRRate.Enabled = false;
            this.lblRRate.Location = new System.Drawing.Point(64, 200);
            this.lblRRate.Name = "lblRRate";
            this.lblRRate.Size = new System.Drawing.Size(58, 21);
            this.lblRRate.TabIndex = 13;
            this.lblRRate.Text = "收益率";
            // 
            // lblRMoney
            // 
            this.lblRMoney.AutoSize = true;
            this.lblRMoney.Enabled = false;
            this.lblRMoney.Location = new System.Drawing.Point(64, 160);
            this.lblRMoney.Name = "lblRMoney";
            this.lblRMoney.Size = new System.Drawing.Size(74, 21);
            this.lblRMoney.TabIndex = 12;
            this.lblRMoney.Text = "起投金额";
            // 
            // lblRTime
            // 
            this.lblRTime.AutoSize = true;
            this.lblRTime.Enabled = false;
            this.lblRTime.Location = new System.Drawing.Point(64, 104);
            this.lblRTime.Name = "lblRTime";
            this.lblRTime.Size = new System.Drawing.Size(74, 21);
            this.lblRTime.TabIndex = 11;
            this.lblRTime.Text = "投资期限";
            // 
            // grpRTime
            // 
            this.grpRTime.Controls.Add(this.lblRTimeHigh);
            this.grpRTime.Controls.Add(this.txtRTimeHigh);
            this.grpRTime.Controls.Add(this.lblRTimeLow);
            this.grpRTime.Controls.Add(this.txtRTimeLow);
            this.grpRTime.Controls.Add(this.rdoRTime4);
            this.grpRTime.Controls.Add(this.rdoRTime3);
            this.grpRTime.Controls.Add(this.rdoRTime2);
            this.grpRTime.Controls.Add(this.rdoRTime1);
            this.grpRTime.Location = new System.Drawing.Point(144, 88);
            this.grpRTime.Name = "grpRTime";
            this.grpRTime.Size = new System.Drawing.Size(616, 48);
            this.grpRTime.TabIndex = 15;
            this.grpRTime.TabStop = false;
            // 
            // lblRTimeHigh
            // 
            this.lblRTimeHigh.AutoSize = true;
            this.lblRTimeHigh.Enabled = false;
            this.lblRTimeHigh.Location = new System.Drawing.Point(576, 24);
            this.lblRTimeHigh.Name = "lblRTimeHigh";
            this.lblRTimeHigh.Size = new System.Drawing.Size(42, 21);
            this.lblRTimeHigh.TabIndex = 8;
            this.lblRTimeHigh.Text = "个月";
            // 
            // txtRTimeHigh
            // 
            this.txtRTimeHigh.Enabled = false;
            this.txtRTimeHigh.Location = new System.Drawing.Point(504, 16);
            this.txtRTimeHigh.Name = "txtRTimeHigh";
            this.txtRTimeHigh.Size = new System.Drawing.Size(56, 29);
            this.txtRTimeHigh.TabIndex = 7;
            // 
            // lblRTimeLow
            // 
            this.lblRTimeLow.AutoSize = true;
            this.lblRTimeLow.Enabled = false;
            this.lblRTimeLow.Location = new System.Drawing.Point(440, 24);
            this.lblRTimeLow.Name = "lblRTimeLow";
            this.lblRTimeLow.Size = new System.Drawing.Size(54, 21);
            this.lblRTimeLow.TabIndex = 6;
            this.lblRTimeLow.Text = "个月~";
            // 
            // txtRTimeLow
            // 
            this.txtRTimeLow.Enabled = false;
            this.txtRTimeLow.Location = new System.Drawing.Point(376, 16);
            this.txtRTimeLow.Name = "txtRTimeLow";
            this.txtRTimeLow.Size = new System.Drawing.Size(64, 29);
            this.txtRTimeLow.TabIndex = 4;
            // 
            // rdoRTime4
            // 
            this.rdoRTime4.AutoSize = true;
            this.rdoRTime4.Location = new System.Drawing.Point(320, 16);
            this.rdoRTime4.Name = "rdoRTime4";
            this.rdoRTime4.Size = new System.Drawing.Size(60, 25);
            this.rdoRTime4.TabIndex = 3;
            this.rdoRTime4.Tag = "0";
            this.rdoRTime4.Text = "其它";
            this.rdoRTime4.UseVisualStyleBackColor = true;
            this.rdoRTime4.CheckedChanged += new System.EventHandler(this.rdoRTime4_CheckedChanged);
            // 
            // rdoRTime3
            // 
            this.rdoRTime3.AutoSize = true;
            this.rdoRTime3.Location = new System.Drawing.Point(208, 16);
            this.rdoRTime3.Name = "rdoRTime3";
            this.rdoRTime3.Size = new System.Drawing.Size(110, 25);
            this.rdoRTime3.TabIndex = 2;
            this.rdoRTime3.Tag = "1";
            this.rdoRTime3.Text = "12个月以上";
            this.rdoRTime3.UseVisualStyleBackColor = true;
            this.rdoRTime3.CheckedChanged += new System.EventHandler(this.rdoRTime3_CheckedChanged);
            // 
            // rdoRTime2
            // 
            this.rdoRTime2.AutoSize = true;
            this.rdoRTime2.Location = new System.Drawing.Point(104, 16);
            this.rdoRTime2.Name = "rdoRTime2";
            this.rdoRTime2.Size = new System.Drawing.Size(94, 25);
            this.rdoRTime2.TabIndex = 1;
            this.rdoRTime2.Tag = "2";
            this.rdoRTime2.Text = "6-12个月";
            this.rdoRTime2.UseVisualStyleBackColor = true;
            this.rdoRTime2.CheckedChanged += new System.EventHandler(this.rdoRTime2_CheckedChanged);
            // 
            // rdoRTime1
            // 
            this.rdoRTime1.AutoSize = true;
            this.rdoRTime1.Location = new System.Drawing.Point(0, 16);
            this.rdoRTime1.Name = "rdoRTime1";
            this.rdoRTime1.Size = new System.Drawing.Size(101, 25);
            this.rdoRTime1.TabIndex = 0;
            this.rdoRTime1.Tag = "3";
            this.rdoRTime1.Text = "6个月以下";
            this.rdoRTime1.UseVisualStyleBackColor = true;
            this.rdoRTime1.CheckedChanged += new System.EventHandler(this.rdoRTime1_CheckedChanged);
            // 
            // tapAnalyse
            // 
            this.tapAnalyse.Controls.Add(this.btnDelete);
            this.tapAnalyse.Controls.Add(this.btnAdd);
            this.tapAnalyse.Controls.Add(this.grpStatisticTable);
            this.tapAnalyse.Controls.Add(this.mmuStatistic);
            this.tapAnalyse.Location = new System.Drawing.Point(4, 30);
            this.tapAnalyse.Name = "tapAnalyse";
            this.tapAnalyse.Padding = new System.Windows.Forms.Padding(3);
            this.tapAnalyse.Size = new System.Drawing.Size(896, 580);
            this.tapAnalyse.TabIndex = 1;
            this.tapAnalyse.Text = "统计分析";
            this.tapAnalyse.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnDelete.Location = new System.Drawing.Point(728, 512);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 32);
            this.btnDelete.TabIndex = 19;
            this.btnDelete.Text = "删除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnAdd.Location = new System.Drawing.Point(632, 512);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 32);
            this.btnAdd.TabIndex = 18;
            this.btnAdd.Text = "增加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // grpStatisticTable
            // 
            this.grpStatisticTable.AllowUserToAddRows = false;
            this.grpStatisticTable.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter;
            this.grpStatisticTable.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.grpStatisticTable.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grpStatisticTable.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grpStatisticTable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.grpStatisticTable.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedVertical;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grpStatisticTable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.grpStatisticTable.ColumnHeadersHeight = 30;
            this.grpStatisticTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnTime,
            this.ColumnType,
            this.ColumnMoney,
            this.ColumnName,
            this.Other});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grpStatisticTable.DefaultCellStyle = dataGridViewCellStyle8;
            this.grpStatisticTable.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.grpStatisticTable.Location = new System.Drawing.Point(0, 40);
            this.grpStatisticTable.Name = "grpStatisticTable";
            this.grpStatisticTable.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grpStatisticTable.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.grpStatisticTable.RowHeadersVisible = false;
            this.grpStatisticTable.RowHeadersWidth = 100;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.grpStatisticTable.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.grpStatisticTable.RowTemplate.Height = 23;
            this.grpStatisticTable.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.grpStatisticTable.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grpStatisticTable.Size = new System.Drawing.Size(880, 464);
            this.grpStatisticTable.TabIndex = 17;
            // 
            // mmuStatistic
            // 
            this.mmuStatistic.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.mmuStatistic.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mmuNew,
            this.mmuSave,
            this.mmuEmpty,
            this.mmuImport,
            this.mmuExport,
            this.mmuChart});
            this.mmuStatistic.Location = new System.Drawing.Point(3, 3);
            this.mmuStatistic.Name = "mmuStatistic";
            this.mmuStatistic.Size = new System.Drawing.Size(890, 29);
            this.mmuStatistic.TabIndex = 0;
            this.mmuStatistic.Text = "menuStrip1";
            // 
            // mmuNew
            // 
            this.mmuNew.Name = "mmuNew";
            this.mmuNew.Size = new System.Drawing.Size(54, 25);
            this.mmuNew.Text = "新建";
            this.mmuNew.Click += new System.EventHandler(this.mmuNew_Click);
            // 
            // mmuSave
            // 
            this.mmuSave.Name = "mmuSave";
            this.mmuSave.Size = new System.Drawing.Size(54, 25);
            this.mmuSave.Text = "保存";
            this.mmuSave.Click += new System.EventHandler(this.mmuSave_Click);
            // 
            // mmuEmpty
            // 
            this.mmuEmpty.Name = "mmuEmpty";
            this.mmuEmpty.Size = new System.Drawing.Size(54, 25);
            this.mmuEmpty.Text = "清空";
            this.mmuEmpty.Click += new System.EventHandler(this.mmuEmpty_Click);
            // 
            // mmuImport
            // 
            this.mmuImport.Name = "mmuImport";
            this.mmuImport.Size = new System.Drawing.Size(54, 25);
            this.mmuImport.Text = "导入";
            this.mmuImport.Click += new System.EventHandler(this.mmuImport_Click);
            // 
            // mmuExport
            // 
            this.mmuExport.Name = "mmuExport";
            this.mmuExport.Size = new System.Drawing.Size(54, 25);
            this.mmuExport.Text = "导出";
            this.mmuExport.Click += new System.EventHandler(this.mmuExport_Click);
            // 
            // mmuChart
            // 
            this.mmuChart.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.mmuChart.Name = "mmuChart";
            this.mmuChart.Size = new System.Drawing.Size(86, 25);
            this.mmuChart.Text = "图表分析";
            this.mmuChart.Click += new System.EventHandler(this.mmuChart_Click);
            // 
            // tapSearch
            // 
            this.tapSearch.Controls.Add(this.lblShowPg);
            this.tapSearch.Controls.Add(this.btnToRecord);
            this.tapSearch.Controls.Add(this.btnRateConfirm);
            this.tapSearch.Controls.Add(this.btnTimeConfirm);
            this.tapSearch.Controls.Add(this.btnPageDown);
            this.tapSearch.Controls.Add(this.btnPageUp);
            this.tapSearch.Controls.Add(this.grpSearch);
            this.tapSearch.Controls.Add(this.txtSearch);
            this.tapSearch.Controls.Add(this.btnRush);
            this.tapSearch.Controls.Add(this.btnMoneyConfirm);
            this.tapSearch.Controls.Add(this.lblSplit);
            this.tapSearch.Controls.Add(this.grpSRate);
            this.tapSearch.Controls.Add(this.grpSMoney);
            this.tapSearch.Controls.Add(this.btnSearch);
            this.tapSearch.Controls.Add(this.lblSRate);
            this.tapSearch.Controls.Add(this.lblSMoney);
            this.tapSearch.Controls.Add(this.lblSTime);
            this.tapSearch.Controls.Add(this.grpSTime);
            this.tapSearch.Controls.Add(this.grpSort);
            this.tapSearch.Controls.Add(this.grpSortMode);
            this.tapSearch.Location = new System.Drawing.Point(4, 30);
            this.tapSearch.Margin = new System.Windows.Forms.Padding(1);
            this.tapSearch.Name = "tapSearch";
            this.tapSearch.Padding = new System.Windows.Forms.Padding(1);
            this.tapSearch.Size = new System.Drawing.Size(896, 580);
            this.tapSearch.TabIndex = 0;
            this.tapSearch.Text = "搜索查询";
            this.tapSearch.UseVisualStyleBackColor = true;
            // 
            // lblShowPg
            // 
            this.lblShowPg.AutoSize = true;
            this.lblShowPg.Enabled = false;
            this.lblShowPg.Location = new System.Drawing.Point(11, 534);
            this.lblShowPg.Name = "lblShowPg";
            this.lblShowPg.Size = new System.Drawing.Size(55, 21);
            this.lblShowPg.TabIndex = 28;
            this.lblShowPg.Text = "label1";
            // 
            // btnToRecord
            // 
            this.btnToRecord.Location = new System.Drawing.Point(544, 528);
            this.btnToRecord.Name = "btnToRecord";
            this.btnToRecord.Size = new System.Drawing.Size(96, 32);
            this.btnToRecord.TabIndex = 27;
            this.btnToRecord.Text = "加到记录";
            this.btnToRecord.UseVisualStyleBackColor = true;
            this.btnToRecord.Click += new System.EventHandler(this.btnToRecord_Click);
            // 
            // btnRateConfirm
            // 
            this.btnRateConfirm.Enabled = false;
            this.btnRateConfirm.Location = new System.Drawing.Point(808, 144);
            this.btnRateConfirm.Name = "btnRateConfirm";
            this.btnRateConfirm.Size = new System.Drawing.Size(75, 32);
            this.btnRateConfirm.TabIndex = 26;
            this.btnRateConfirm.Tag = "0";
            this.btnRateConfirm.Text = "确定";
            this.btnRateConfirm.UseVisualStyleBackColor = true;
            this.btnRateConfirm.Click += new System.EventHandler(this.btnRateConfirm_Click);
            // 
            // btnTimeConfirm
            // 
            this.btnTimeConfirm.Enabled = false;
            this.btnTimeConfirm.Location = new System.Drawing.Point(808, 48);
            this.btnTimeConfirm.Name = "btnTimeConfirm";
            this.btnTimeConfirm.Size = new System.Drawing.Size(75, 32);
            this.btnTimeConfirm.TabIndex = 25;
            this.btnTimeConfirm.Tag = "0";
            this.btnTimeConfirm.Text = "确定";
            this.btnTimeConfirm.UseVisualStyleBackColor = true;
            this.btnTimeConfirm.Click += new System.EventHandler(this.btnTimeConfirm_Click);
            // 
            // btnPageDown
            // 
            this.btnPageDown.Location = new System.Drawing.Point(764, 528);
            this.btnPageDown.Name = "btnPageDown";
            this.btnPageDown.Size = new System.Drawing.Size(75, 32);
            this.btnPageDown.TabIndex = 18;
            this.btnPageDown.Text = "下一页";
            this.btnPageDown.UseVisualStyleBackColor = true;
            this.btnPageDown.Click += new System.EventHandler(this.btnPageDown_Click);
            // 
            // btnPageUp
            // 
            this.btnPageUp.Location = new System.Drawing.Point(669, 528);
            this.btnPageUp.Name = "btnPageUp";
            this.btnPageUp.Size = new System.Drawing.Size(75, 32);
            this.btnPageUp.TabIndex = 17;
            this.btnPageUp.Text = "上一页";
            this.btnPageUp.UseVisualStyleBackColor = true;
            this.btnPageUp.Click += new System.EventHandler(this.btnPageUp_Click);
            // 
            // grpSearch
            // 
            this.grpSearch.AllowUserToAddRows = false;
            this.grpSearch.AllowUserToDeleteRows = false;
            this.grpSearch.AllowUserToResizeColumns = false;
            this.grpSearch.AllowUserToResizeRows = false;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter;
            this.grpSearch.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.grpSearch.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.grpSearch.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.grpSearch.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.grpSearch.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedVertical;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grpSearch.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.grpSearch.ColumnHeadersHeight = 30;
            this.grpSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.grpSearch.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name,
            this.time,
            this.money,
            this.rate,
            this.inverst});
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grpSearch.DefaultCellStyle = dataGridViewCellStyle13;
            this.grpSearch.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.grpSearch.Location = new System.Drawing.Point(8, 232);
            this.grpSearch.Name = "grpSearch";
            this.grpSearch.ReadOnly = true;
            this.grpSearch.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grpSearch.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.grpSearch.RowHeadersVisible = false;
            this.grpSearch.RowHeadersWidth = 100;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.grpSearch.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.grpSearch.RowTemplate.Height = 23;
            this.grpSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.grpSearch.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grpSearch.Size = new System.Drawing.Size(864, 290);
            this.grpSearch.TabIndex = 16;
            this.grpSearch.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grpSearch_CellContentClick);
            this.grpSearch.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.grpSearch_CellMouseClick);
            this.grpSearch.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.grpSearch_CellMouseDoubleClick);
            // 
            // name
            // 
            this.name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.name.DataPropertyName = "name";
            this.name.HeaderText = "项目";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            this.name.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // time
            // 
            this.time.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.time.DataPropertyName = "time";
            this.time.HeaderText = "投资期限";
            this.time.Name = "time";
            this.time.ReadOnly = true;
            this.time.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // money
            // 
            this.money.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.money.DataPropertyName = "money";
            this.money.HeaderText = "起投金额";
            this.money.Name = "money";
            this.money.ReadOnly = true;
            this.money.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // rate
            // 
            this.rate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.rate.DataPropertyName = "rate";
            this.rate.HeaderText = "收益率";
            this.rate.Name = "rate";
            this.rate.ReadOnly = true;
            this.rate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // inverst
            // 
            this.inverst.HeaderText = "投资";
            this.inverst.Name = "inverst";
            this.inverst.ReadOnly = true;
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(544, 8);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(248, 29);
            this.txtSearch.TabIndex = 3;
            // 
            // btnRush
            // 
            this.btnRush.Location = new System.Drawing.Point(808, 192);
            this.btnRush.Name = "btnRush";
            this.btnRush.Size = new System.Drawing.Size(75, 32);
            this.btnRush.TabIndex = 13;
            this.btnRush.Text = "抢购";
            this.btnRush.UseVisualStyleBackColor = true;
            this.btnRush.Click += new System.EventHandler(this.btnRush_Click);
            // 
            // btnMoneyConfirm
            // 
            this.btnMoneyConfirm.Enabled = false;
            this.btnMoneyConfirm.Location = new System.Drawing.Point(808, 96);
            this.btnMoneyConfirm.Name = "btnMoneyConfirm";
            this.btnMoneyConfirm.Size = new System.Drawing.Size(75, 32);
            this.btnMoneyConfirm.TabIndex = 12;
            this.btnMoneyConfirm.Tag = "0";
            this.btnMoneyConfirm.Text = "确定";
            this.btnMoneyConfirm.UseVisualStyleBackColor = true;
            this.btnMoneyConfirm.Click += new System.EventHandler(this.btnMoneyConfirm_Click);
            // 
            // lblSplit
            // 
            this.lblSplit.BackColor = System.Drawing.Color.DarkGray;
            this.lblSplit.Enabled = false;
            this.lblSplit.Location = new System.Drawing.Point(8, 184);
            this.lblSplit.Name = "lblSplit";
            this.lblSplit.Size = new System.Drawing.Size(856, 2);
            this.lblSplit.TabIndex = 11;
            this.lblSplit.Text = "label10";
            // 
            // grpSRate
            // 
            this.grpSRate.Controls.Add(this.rdoRateAll);
            this.grpSRate.Controls.Add(this.lblSRateHigh);
            this.grpSRate.Controls.Add(this.txtSRateHigh);
            this.grpSRate.Controls.Add(this.lblSRateLow);
            this.grpSRate.Controls.Add(this.txtSRateLow);
            this.grpSRate.Controls.Add(this.rdoSRate4);
            this.grpSRate.Controls.Add(this.rdoSRate3);
            this.grpSRate.Controls.Add(this.rdoSRate2);
            this.grpSRate.Controls.Add(this.rdoSRate1);
            this.grpSRate.Location = new System.Drawing.Point(80, 128);
            this.grpSRate.Name = "grpSRate";
            this.grpSRate.Size = new System.Drawing.Size(720, 48);
            this.grpSRate.TabIndex = 10;
            this.grpSRate.TabStop = false;
            // 
            // rdoRateAll
            // 
            this.rdoRateAll.AutoSize = true;
            this.rdoRateAll.Checked = true;
            this.rdoRateAll.Location = new System.Drawing.Point(16, 16);
            this.rdoRateAll.Name = "rdoRateAll";
            this.rdoRateAll.Size = new System.Drawing.Size(60, 25);
            this.rdoRateAll.TabIndex = 30;
            this.rdoRateAll.TabStop = true;
            this.rdoRateAll.Tag = "4";
            this.rdoRateAll.Text = "不限";
            this.rdoRateAll.UseVisualStyleBackColor = true;
            this.rdoRateAll.CheckedChanged += new System.EventHandler(this.rdoRateAll_CheckedChanged);
            // 
            // lblSRateHigh
            // 
            this.lblSRateHigh.AutoSize = true;
            this.lblSRateHigh.Enabled = false;
            this.lblSRateHigh.Location = new System.Drawing.Point(680, 24);
            this.lblSRateHigh.Name = "lblSRateHigh";
            this.lblSRateHigh.Size = new System.Drawing.Size(24, 21);
            this.lblSRateHigh.TabIndex = 8;
            this.lblSRateHigh.Text = "%";
            // 
            // txtSRateHigh
            // 
            this.txtSRateHigh.Enabled = false;
            this.txtSRateHigh.Location = new System.Drawing.Point(608, 16);
            this.txtSRateHigh.Name = "txtSRateHigh";
            this.txtSRateHigh.Size = new System.Drawing.Size(56, 29);
            this.txtSRateHigh.TabIndex = 7;
            // 
            // lblSRateLow
            // 
            this.lblSRateLow.AutoSize = true;
            this.lblSRateLow.Enabled = false;
            this.lblSRateLow.Location = new System.Drawing.Point(544, 24);
            this.lblSRateLow.Name = "lblSRateLow";
            this.lblSRateLow.Size = new System.Drawing.Size(36, 21);
            this.lblSRateLow.TabIndex = 6;
            this.lblSRateLow.Text = "%~";
            // 
            // txtSRateLow
            // 
            this.txtSRateLow.Enabled = false;
            this.txtSRateLow.Location = new System.Drawing.Point(464, 16);
            this.txtSRateLow.Name = "txtSRateLow";
            this.txtSRateLow.Size = new System.Drawing.Size(64, 29);
            this.txtSRateLow.TabIndex = 4;
            // 
            // rdoSRate4
            // 
            this.rdoSRate4.AutoSize = true;
            this.rdoSRate4.Location = new System.Drawing.Point(400, 16);
            this.rdoSRate4.Name = "rdoSRate4";
            this.rdoSRate4.Size = new System.Drawing.Size(60, 25);
            this.rdoSRate4.TabIndex = 3;
            this.rdoSRate4.Tag = "0";
            this.rdoSRate4.Text = "其它";
            this.rdoSRate4.UseVisualStyleBackColor = true;
            this.rdoSRate4.CheckedChanged += new System.EventHandler(this.rdoSRate4_CheckedChanged);
            // 
            // rdoSRate3
            // 
            this.rdoSRate3.AutoSize = true;
            this.rdoSRate3.Location = new System.Drawing.Point(288, 16);
            this.rdoSRate3.Name = "rdoSRate3";
            this.rdoSRate3.Size = new System.Drawing.Size(92, 25);
            this.rdoSRate3.TabIndex = 2;
            this.rdoSRate3.Tag = "1";
            this.rdoSRate3.Text = "10%以上";
            this.rdoSRate3.UseVisualStyleBackColor = true;
            this.rdoSRate3.CheckedChanged += new System.EventHandler(this.rdoSRate3_CheckedChanged);
            // 
            // rdoSRate2
            // 
            this.rdoSRate2.AutoSize = true;
            this.rdoSRate2.Location = new System.Drawing.Point(184, 16);
            this.rdoSRate2.Name = "rdoSRate2";
            this.rdoSRate2.Size = new System.Drawing.Size(90, 25);
            this.rdoSRate2.TabIndex = 1;
            this.rdoSRate2.Tag = "2";
            this.rdoSRate2.Text = "5%-10%";
            this.rdoSRate2.UseVisualStyleBackColor = true;
            this.rdoSRate2.CheckedChanged += new System.EventHandler(this.rdoSRate2_CheckedChanged);
            // 
            // rdoSRate1
            // 
            this.rdoSRate1.AutoSize = true;
            this.rdoSRate1.Location = new System.Drawing.Point(80, 16);
            this.rdoSRate1.Name = "rdoSRate1";
            this.rdoSRate1.Size = new System.Drawing.Size(83, 25);
            this.rdoSRate1.TabIndex = 0;
            this.rdoSRate1.Tag = "3";
            this.rdoSRate1.Text = "5%以下";
            this.rdoSRate1.UseVisualStyleBackColor = true;
            this.rdoSRate1.CheckedChanged += new System.EventHandler(this.rdoSRate1_CheckedChanged);
            // 
            // grpSMoney
            // 
            this.grpSMoney.Controls.Add(this.rdoMoneyAll);
            this.grpSMoney.Controls.Add(this.lblSMoneyHigh);
            this.grpSMoney.Controls.Add(this.txtSMoneyHigh);
            this.grpSMoney.Controls.Add(this.lblSMoneyLow);
            this.grpSMoney.Controls.Add(this.txtSMoneyLow);
            this.grpSMoney.Controls.Add(this.rdoSMoney4);
            this.grpSMoney.Controls.Add(this.rdoSMoney3);
            this.grpSMoney.Controls.Add(this.rdoSMoney2);
            this.grpSMoney.Controls.Add(this.rdoSMoney1);
            this.grpSMoney.Location = new System.Drawing.Point(80, 80);
            this.grpSMoney.Name = "grpSMoney";
            this.grpSMoney.Size = new System.Drawing.Size(720, 56);
            this.grpSMoney.TabIndex = 9;
            this.grpSMoney.TabStop = false;
            // 
            // rdoMoneyAll
            // 
            this.rdoMoneyAll.AutoSize = true;
            this.rdoMoneyAll.Checked = true;
            this.rdoMoneyAll.Location = new System.Drawing.Point(16, 16);
            this.rdoMoneyAll.Name = "rdoMoneyAll";
            this.rdoMoneyAll.Size = new System.Drawing.Size(60, 25);
            this.rdoMoneyAll.TabIndex = 29;
            this.rdoMoneyAll.TabStop = true;
            this.rdoMoneyAll.Tag = "4";
            this.rdoMoneyAll.Text = "不限";
            this.rdoMoneyAll.UseVisualStyleBackColor = true;
            this.rdoMoneyAll.CheckedChanged += new System.EventHandler(this.rdoMoneyAll_CheckedChanged);
            // 
            // lblSMoneyHigh
            // 
            this.lblSMoneyHigh.AutoSize = true;
            this.lblSMoneyHigh.Enabled = false;
            this.lblSMoneyHigh.Location = new System.Drawing.Point(680, 24);
            this.lblSMoneyHigh.Name = "lblSMoneyHigh";
            this.lblSMoneyHigh.Size = new System.Drawing.Size(26, 21);
            this.lblSMoneyHigh.TabIndex = 8;
            this.lblSMoneyHigh.Text = "万";
            // 
            // txtSMoneyHigh
            // 
            this.txtSMoneyHigh.Enabled = false;
            this.txtSMoneyHigh.Location = new System.Drawing.Point(608, 16);
            this.txtSMoneyHigh.Name = "txtSMoneyHigh";
            this.txtSMoneyHigh.Size = new System.Drawing.Size(56, 29);
            this.txtSMoneyHigh.TabIndex = 7;
            // 
            // lblSMoneyLow
            // 
            this.lblSMoneyLow.AutoSize = true;
            this.lblSMoneyLow.Enabled = false;
            this.lblSMoneyLow.Location = new System.Drawing.Point(552, 24);
            this.lblSMoneyLow.Name = "lblSMoneyLow";
            this.lblSMoneyLow.Size = new System.Drawing.Size(38, 21);
            this.lblSMoneyLow.TabIndex = 6;
            this.lblSMoneyLow.Text = "万~";
            // 
            // txtSMoneyLow
            // 
            this.txtSMoneyLow.Enabled = false;
            this.txtSMoneyLow.Location = new System.Drawing.Point(464, 16);
            this.txtSMoneyLow.Name = "txtSMoneyLow";
            this.txtSMoneyLow.Size = new System.Drawing.Size(64, 29);
            this.txtSMoneyLow.TabIndex = 4;
            // 
            // rdoSMoney4
            // 
            this.rdoSMoney4.AutoSize = true;
            this.rdoSMoney4.Location = new System.Drawing.Point(400, 16);
            this.rdoSMoney4.Name = "rdoSMoney4";
            this.rdoSMoney4.Size = new System.Drawing.Size(60, 25);
            this.rdoSMoney4.TabIndex = 3;
            this.rdoSMoney4.Tag = "0";
            this.rdoSMoney4.Text = "其它";
            this.rdoSMoney4.UseVisualStyleBackColor = true;
            this.rdoSMoney4.CheckedChanged += new System.EventHandler(this.rdoSMoney4_CheckedChanged);
            // 
            // rdoSMoney3
            // 
            this.rdoSMoney3.AutoSize = true;
            this.rdoSMoney3.Location = new System.Drawing.Point(288, 16);
            this.rdoSMoney3.Name = "rdoSMoney3";
            this.rdoSMoney3.Size = new System.Drawing.Size(78, 25);
            this.rdoSMoney3.TabIndex = 2;
            this.rdoSMoney3.Tag = "1";
            this.rdoSMoney3.Text = "5-10万";
            this.rdoSMoney3.UseVisualStyleBackColor = true;
            this.rdoSMoney3.CheckedChanged += new System.EventHandler(this.rdoSMoney3_CheckedChanged);
            // 
            // rdoSMoney2
            // 
            this.rdoSMoney2.AutoSize = true;
            this.rdoSMoney2.Location = new System.Drawing.Point(184, 16);
            this.rdoSMoney2.Name = "rdoSMoney2";
            this.rdoSMoney2.Size = new System.Drawing.Size(69, 25);
            this.rdoSMoney2.TabIndex = 1;
            this.rdoSMoney2.Tag = "2";
            this.rdoSMoney2.Text = "1-5万";
            this.rdoSMoney2.UseVisualStyleBackColor = true;
            this.rdoSMoney2.CheckedChanged += new System.EventHandler(this.rdoSMoney2_CheckedChanged);
            // 
            // rdoSMoney1
            // 
            this.rdoSMoney1.AutoSize = true;
            this.rdoSMoney1.Location = new System.Drawing.Point(80, 16);
            this.rdoSMoney1.Name = "rdoSMoney1";
            this.rdoSMoney1.Size = new System.Drawing.Size(85, 25);
            this.rdoSMoney1.TabIndex = 0;
            this.rdoSMoney1.Tag = "3";
            this.rdoSMoney1.Text = "1万以下";
            this.rdoSMoney1.UseVisualStyleBackColor = true;
            this.rdoSMoney1.CheckedChanged += new System.EventHandler(this.rdoSMoney1_CheckedChanged);
            // 
            // btnSearch
            // 
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnSearch.Location = new System.Drawing.Point(808, 8);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 32);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "搜索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblSRate
            // 
            this.lblSRate.AutoSize = true;
            this.lblSRate.Enabled = false;
            this.lblSRate.Location = new System.Drawing.Point(8, 144);
            this.lblSRate.Name = "lblSRate";
            this.lblSRate.Size = new System.Drawing.Size(58, 21);
            this.lblSRate.TabIndex = 2;
            this.lblSRate.Text = "收益率";
            // 
            // lblSMoney
            // 
            this.lblSMoney.AutoSize = true;
            this.lblSMoney.Enabled = false;
            this.lblSMoney.Location = new System.Drawing.Point(8, 96);
            this.lblSMoney.Name = "lblSMoney";
            this.lblSMoney.Size = new System.Drawing.Size(74, 21);
            this.lblSMoney.TabIndex = 1;
            this.lblSMoney.Text = "起投金额";
            // 
            // lblSTime
            // 
            this.lblSTime.AutoSize = true;
            this.lblSTime.Enabled = false;
            this.lblSTime.Location = new System.Drawing.Point(8, 48);
            this.lblSTime.Name = "lblSTime";
            this.lblSTime.Size = new System.Drawing.Size(74, 21);
            this.lblSTime.TabIndex = 0;
            this.lblSTime.Text = "投资期限";
            // 
            // grpSTime
            // 
            this.grpSTime.Controls.Add(this.rdoTimeAll);
            this.grpSTime.Controls.Add(this.lblSTimeHigh);
            this.grpSTime.Controls.Add(this.txtSTimeHigh);
            this.grpSTime.Controls.Add(this.lblSTimeLow);
            this.grpSTime.Controls.Add(this.txtSTimeLow);
            this.grpSTime.Controls.Add(this.rdoSTime4);
            this.grpSTime.Controls.Add(this.rdoSTime3);
            this.grpSTime.Controls.Add(this.rdoSTime2);
            this.grpSTime.Controls.Add(this.rdoSTime1);
            this.grpSTime.Location = new System.Drawing.Point(80, 32);
            this.grpSTime.Name = "grpSTime";
            this.grpSTime.Size = new System.Drawing.Size(720, 48);
            this.grpSTime.TabIndex = 5;
            this.grpSTime.TabStop = false;
            // 
            // rdoTimeAll
            // 
            this.rdoTimeAll.AutoSize = true;
            this.rdoTimeAll.Checked = true;
            this.rdoTimeAll.Location = new System.Drawing.Point(16, 16);
            this.rdoTimeAll.Name = "rdoTimeAll";
            this.rdoTimeAll.Size = new System.Drawing.Size(60, 25);
            this.rdoTimeAll.TabIndex = 9;
            this.rdoTimeAll.TabStop = true;
            this.rdoTimeAll.Tag = "4";
            this.rdoTimeAll.Text = "不限";
            this.rdoTimeAll.UseVisualStyleBackColor = true;
            this.rdoTimeAll.CheckedChanged += new System.EventHandler(this.rdoTimeAll_CheckedChanged);
            // 
            // lblSTimeHigh
            // 
            this.lblSTimeHigh.AutoSize = true;
            this.lblSTimeHigh.Enabled = false;
            this.lblSTimeHigh.Location = new System.Drawing.Point(672, 24);
            this.lblSTimeHigh.Name = "lblSTimeHigh";
            this.lblSTimeHigh.Size = new System.Drawing.Size(42, 21);
            this.lblSTimeHigh.TabIndex = 8;
            this.lblSTimeHigh.Text = "个月";
            // 
            // txtSTimeHigh
            // 
            this.txtSTimeHigh.Enabled = false;
            this.txtSTimeHigh.Location = new System.Drawing.Point(608, 16);
            this.txtSTimeHigh.Name = "txtSTimeHigh";
            this.txtSTimeHigh.Size = new System.Drawing.Size(56, 29);
            this.txtSTimeHigh.TabIndex = 7;
            // 
            // lblSTimeLow
            // 
            this.lblSTimeLow.AutoSize = true;
            this.lblSTimeLow.Enabled = false;
            this.lblSTimeLow.Location = new System.Drawing.Point(544, 24);
            this.lblSTimeLow.Name = "lblSTimeLow";
            this.lblSTimeLow.Size = new System.Drawing.Size(54, 21);
            this.lblSTimeLow.TabIndex = 6;
            this.lblSTimeLow.Text = "个月~";
            // 
            // txtSTimeLow
            // 
            this.txtSTimeLow.Enabled = false;
            this.txtSTimeLow.Location = new System.Drawing.Point(464, 19);
            this.txtSTimeLow.Name = "txtSTimeLow";
            this.txtSTimeLow.Size = new System.Drawing.Size(64, 29);
            this.txtSTimeLow.TabIndex = 4;
            // 
            // rdoSTime4
            // 
            this.rdoSTime4.AutoSize = true;
            this.rdoSTime4.Location = new System.Drawing.Point(400, 16);
            this.rdoSTime4.Name = "rdoSTime4";
            this.rdoSTime4.Size = new System.Drawing.Size(60, 25);
            this.rdoSTime4.TabIndex = 3;
            this.rdoSTime4.Tag = "0";
            this.rdoSTime4.Text = "其它";
            this.rdoSTime4.UseVisualStyleBackColor = true;
            this.rdoSTime4.CheckedChanged += new System.EventHandler(this.rdoSTime4_CheckedChanged);
            // 
            // rdoSTime3
            // 
            this.rdoSTime3.AutoSize = true;
            this.rdoSTime3.Location = new System.Drawing.Point(288, 16);
            this.rdoSTime3.Name = "rdoSTime3";
            this.rdoSTime3.Size = new System.Drawing.Size(110, 25);
            this.rdoSTime3.TabIndex = 2;
            this.rdoSTime3.Tag = "1";
            this.rdoSTime3.Text = "12个月以上";
            this.rdoSTime3.UseVisualStyleBackColor = true;
            this.rdoSTime3.CheckedChanged += new System.EventHandler(this.rdoSTime3_CheckedChanged);
            // 
            // rdoSTime2
            // 
            this.rdoSTime2.AutoSize = true;
            this.rdoSTime2.Location = new System.Drawing.Point(184, 16);
            this.rdoSTime2.Name = "rdoSTime2";
            this.rdoSTime2.Size = new System.Drawing.Size(94, 25);
            this.rdoSTime2.TabIndex = 1;
            this.rdoSTime2.Tag = "2";
            this.rdoSTime2.Text = "6-12个月";
            this.rdoSTime2.UseVisualStyleBackColor = true;
            this.rdoSTime2.CheckedChanged += new System.EventHandler(this.rdoSTime2_CheckedChanged);
            // 
            // rdoSTime1
            // 
            this.rdoSTime1.AutoSize = true;
            this.rdoSTime1.Location = new System.Drawing.Point(80, 16);
            this.rdoSTime1.Name = "rdoSTime1";
            this.rdoSTime1.Size = new System.Drawing.Size(101, 25);
            this.rdoSTime1.TabIndex = 0;
            this.rdoSTime1.Tag = "3";
            this.rdoSTime1.Text = "6个月以下";
            this.rdoSTime1.UseVisualStyleBackColor = true;
            this.rdoSTime1.CheckedChanged += new System.EventHandler(this.rdoSTime1_CheckedChanged);
            // 
            // grpSort
            // 
            this.grpSort.Controls.Add(this.rdoSortRate);
            this.grpSort.Controls.Add(this.rdoSortMoney);
            this.grpSort.Controls.Add(this.rdoSortTime);
            this.grpSort.Controls.Add(this.rdoSortDefault);
            this.grpSort.Location = new System.Drawing.Point(24, 184);
            this.grpSort.Name = "grpSort";
            this.grpSort.Size = new System.Drawing.Size(400, 48);
            this.grpSort.TabIndex = 14;
            this.grpSort.TabStop = false;
            // 
            // rdoSortRate
            // 
            this.rdoSortRate.AutoSize = true;
            this.rdoSortRate.Location = new System.Drawing.Point(320, 16);
            this.rdoSortRate.Name = "rdoSortRate";
            this.rdoSortRate.Size = new System.Drawing.Size(76, 25);
            this.rdoSortRate.TabIndex = 3;
            this.rdoSortRate.Tag = "3";
            this.rdoSortRate.Text = "收益率";
            this.rdoSortRate.UseVisualStyleBackColor = true;
            this.rdoSortRate.CheckedChanged += new System.EventHandler(this.rdoSortRate_CheckedChanged);
            // 
            // rdoSortMoney
            // 
            this.rdoSortMoney.AutoSize = true;
            this.rdoSortMoney.Location = new System.Drawing.Point(208, 16);
            this.rdoSortMoney.Name = "rdoSortMoney";
            this.rdoSortMoney.Size = new System.Drawing.Size(92, 25);
            this.rdoSortMoney.TabIndex = 2;
            this.rdoSortMoney.Tag = "2";
            this.rdoSortMoney.Text = "起投金额";
            this.rdoSortMoney.UseVisualStyleBackColor = true;
            this.rdoSortMoney.CheckedChanged += new System.EventHandler(this.rdoSortMoney_CheckedChanged);
            // 
            // rdoSortTime
            // 
            this.rdoSortTime.AutoSize = true;
            this.rdoSortTime.Location = new System.Drawing.Point(104, 16);
            this.rdoSortTime.Name = "rdoSortTime";
            this.rdoSortTime.Size = new System.Drawing.Size(92, 25);
            this.rdoSortTime.TabIndex = 1;
            this.rdoSortTime.Tag = "1";
            this.rdoSortTime.Text = "投资期限";
            this.rdoSortTime.UseVisualStyleBackColor = true;
            this.rdoSortTime.CheckedChanged += new System.EventHandler(this.rdoSortTime_CheckedChanged);
            // 
            // rdoSortDefault
            // 
            this.rdoSortDefault.AutoSize = true;
            this.rdoSortDefault.Checked = true;
            this.rdoSortDefault.Location = new System.Drawing.Point(0, 16);
            this.rdoSortDefault.Name = "rdoSortDefault";
            this.rdoSortDefault.Size = new System.Drawing.Size(92, 25);
            this.rdoSortDefault.TabIndex = 0;
            this.rdoSortDefault.TabStop = true;
            this.rdoSortDefault.Tag = "0";
            this.rdoSortDefault.Text = "默认排序";
            this.rdoSortDefault.UseVisualStyleBackColor = true;
            this.rdoSortDefault.CheckedChanged += new System.EventHandler(this.rdoSortDefault_CheckedChanged);
            // 
            // grpSortMode
            // 
            this.grpSortMode.Controls.Add(this.rdoSortDown);
            this.grpSortMode.Controls.Add(this.rdoSortUp);
            this.grpSortMode.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpSortMode.Location = new System.Drawing.Point(432, 192);
            this.grpSortMode.Name = "grpSortMode";
            this.grpSortMode.Size = new System.Drawing.Size(144, 48);
            this.grpSortMode.TabIndex = 15;
            this.grpSortMode.TabStop = false;
            // 
            // rdoSortDown
            // 
            this.rdoSortDown.AutoSize = true;
            this.rdoSortDown.Location = new System.Drawing.Point(72, 16);
            this.rdoSortDown.Name = "rdoSortDown";
            this.rdoSortDown.Size = new System.Drawing.Size(53, 23);
            this.rdoSortDown.TabIndex = 1;
            this.rdoSortDown.Tag = "1";
            this.rdoSortDown.Text = "降序";
            this.rdoSortDown.UseVisualStyleBackColor = true;
            this.rdoSortDown.Visible = false;
            this.rdoSortDown.CheckedChanged += new System.EventHandler(this.rdoSortDown_CheckedChanged);
            // 
            // rdoSortUp
            // 
            this.rdoSortUp.AutoSize = true;
            this.rdoSortUp.Checked = true;
            this.rdoSortUp.Location = new System.Drawing.Point(0, 16);
            this.rdoSortUp.Name = "rdoSortUp";
            this.rdoSortUp.Size = new System.Drawing.Size(53, 23);
            this.rdoSortUp.TabIndex = 0;
            this.rdoSortUp.TabStop = true;
            this.rdoSortUp.Tag = "0";
            this.rdoSortUp.Text = "升序";
            this.rdoSortUp.UseVisualStyleBackColor = true;
            this.rdoSortUp.Visible = false;
            this.rdoSortUp.CheckedChanged += new System.EventHandler(this.rdoSortUp_CheckedChanged);
            // 
            // tabSelectModule
            // 
            this.tabSelectModule.Controls.Add(this.tapSearch);
            this.tabSelectModule.Controls.Add(this.tapAnalyse);
            this.tabSelectModule.Controls.Add(this.tapRush);
            this.tabSelectModule.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabSelectModule.Location = new System.Drawing.Point(0, 120);
            this.tabSelectModule.Name = "tabSelectModule";
            this.tabSelectModule.SelectedIndex = 0;
            this.tabSelectModule.Size = new System.Drawing.Size(904, 614);
            this.tabSelectModule.TabIndex = 1;
            // 
            // ColumnTime
            // 
            this.ColumnTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ColumnTime.FillWeight = 101.5228F;
            this.ColumnTime.HeaderText = "时间";
            this.ColumnTime.Name = "ColumnTime";
            this.ColumnTime.ReadOnly = true;
            this.ColumnTime.Width = 200;
            // 
            // ColumnType
            // 
            this.ColumnType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ColumnType.FillWeight = 86.8386F;
            this.ColumnType.HeaderText = "类型";
            this.ColumnType.Name = "ColumnType";
            this.ColumnType.Width = 170;
            // 
            // ColumnMoney
            // 
            this.ColumnMoney.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ColumnMoney.FillWeight = 86.8386F;
            this.ColumnMoney.HeaderText = "金额";
            this.ColumnMoney.Name = "ColumnMoney";
            this.ColumnMoney.Width = 170;
            // 
            // ColumnName
            // 
            this.ColumnName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ColumnName.FillWeight = 86.8386F;
            this.ColumnName.HeaderText = "项目";
            this.ColumnName.Name = "ColumnName";
            this.ColumnName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ColumnName.Width = 170;
            // 
            // Other
            // 
            this.Other.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Other.FillWeight = 137.9613F;
            this.Other.HeaderText = "其他";
            this.Other.Name = "Other";
            this.Other.ReadOnly = true;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(895, 707);
            this.Controls.Add(this.picLogo2);
            this.Controls.Add(this.picLogo1);
            this.Controls.Add(this.tabSelectModule);
            this.MainMenuStrip = this.mmuStatistic;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picLogo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo1)).EndInit();
            this.tapRush.ResumeLayout(false);
            this.tapRush.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grpRush)).EndInit();
            this.grpRRate.ResumeLayout(false);
            this.grpRRate.PerformLayout();
            this.grpRMoney.ResumeLayout(false);
            this.grpRMoney.PerformLayout();
            this.grpRTime.ResumeLayout(false);
            this.grpRTime.PerformLayout();
            this.tapAnalyse.ResumeLayout(false);
            this.tapAnalyse.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grpStatisticTable)).EndInit();
            this.mmuStatistic.ResumeLayout(false);
            this.mmuStatistic.PerformLayout();
            this.tapSearch.ResumeLayout(false);
            this.tapSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grpSearch)).EndInit();
            this.grpSRate.ResumeLayout(false);
            this.grpSRate.PerformLayout();
            this.grpSMoney.ResumeLayout(false);
            this.grpSMoney.PerformLayout();
            this.grpSTime.ResumeLayout(false);
            this.grpSTime.PerformLayout();
            this.grpSort.ResumeLayout(false);
            this.grpSort.PerformLayout();
            this.grpSortMode.ResumeLayout(false);
            this.grpSortMode.PerformLayout();
            this.tabSelectModule.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picLogo1;
        private System.Windows.Forms.PictureBox picLogo2;
        private System.Windows.Forms.Timer tmrRushReflash;
        private System.Windows.Forms.TabPage tapRush;
        private System.Windows.Forms.DataGridView grpRush;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn1;
        private System.Windows.Forms.Button btnActionRush;
        private System.Windows.Forms.GroupBox grpRRate;
        private System.Windows.Forms.Label lblRRateHigh;
        private System.Windows.Forms.TextBox txtRRateHigh;
        private System.Windows.Forms.Label lblRRateLow;
        private System.Windows.Forms.TextBox txtRRateLow;
        private System.Windows.Forms.RadioButton rdoRRate4;
        private System.Windows.Forms.RadioButton rdoRRate3;
        private System.Windows.Forms.RadioButton rdoRRate2;
        private System.Windows.Forms.RadioButton rdoRRate1;
        private System.Windows.Forms.GroupBox grpRMoney;
        private System.Windows.Forms.Label lblRMoneyHigh;
        private System.Windows.Forms.TextBox txtRMoneyHigh;
        private System.Windows.Forms.Label lblRMoneyLow;
        private System.Windows.Forms.TextBox txtRMoneyLow;
        private System.Windows.Forms.RadioButton rdoRMoney4;
        private System.Windows.Forms.RadioButton rdoRMoney3;
        private System.Windows.Forms.RadioButton rdoRMoney2;
        private System.Windows.Forms.RadioButton rdoRMoney1;
        private System.Windows.Forms.Label lblRRate;
        private System.Windows.Forms.Label lblRMoney;
        private System.Windows.Forms.Label lblRTime;
        private System.Windows.Forms.GroupBox grpRTime;
        private System.Windows.Forms.Label lblRTimeHigh;
        private System.Windows.Forms.TextBox txtRTimeHigh;
        private System.Windows.Forms.Label lblRTimeLow;
        private System.Windows.Forms.TextBox txtRTimeLow;
        private System.Windows.Forms.RadioButton rdoRTime4;
        private System.Windows.Forms.RadioButton rdoRTime3;
        private System.Windows.Forms.RadioButton rdoRTime2;
        private System.Windows.Forms.RadioButton rdoRTime1;
        private System.Windows.Forms.TabPage tapAnalyse;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView grpStatisticTable;
        private System.Windows.Forms.MenuStrip mmuStatistic;
        private System.Windows.Forms.ToolStripMenuItem mmuNew;
        private System.Windows.Forms.ToolStripMenuItem mmuSave;
        private System.Windows.Forms.ToolStripMenuItem mmuEmpty;
        private System.Windows.Forms.ToolStripMenuItem mmuImport;
        private System.Windows.Forms.ToolStripMenuItem mmuExport;
        private System.Windows.Forms.ToolStripMenuItem mmuChart;
        private System.Windows.Forms.TabPage tapSearch;
        private System.Windows.Forms.Button btnToRecord;
        private System.Windows.Forms.Button btnRateConfirm;
        private System.Windows.Forms.Button btnTimeConfirm;
        private System.Windows.Forms.Button btnPageDown;
        private System.Windows.Forms.Button btnPageUp;
        private System.Windows.Forms.DataGridView grpSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn time;
        private System.Windows.Forms.DataGridViewTextBoxColumn money;
        private System.Windows.Forms.DataGridViewTextBoxColumn rate;
        private System.Windows.Forms.DataGridViewButtonColumn inverst;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnRush;
        private System.Windows.Forms.Button btnMoneyConfirm;
        private System.Windows.Forms.Label lblSplit;
        private System.Windows.Forms.GroupBox grpSRate;
        private System.Windows.Forms.Label lblSRateHigh;
        private System.Windows.Forms.TextBox txtSRateHigh;
        private System.Windows.Forms.Label lblSRateLow;
        private System.Windows.Forms.TextBox txtSRateLow;
        private System.Windows.Forms.RadioButton rdoSRate4;
        private System.Windows.Forms.RadioButton rdoSRate3;
        private System.Windows.Forms.RadioButton rdoSRate2;
        private System.Windows.Forms.RadioButton rdoSRate1;
        private System.Windows.Forms.GroupBox grpSMoney;
        private System.Windows.Forms.Label lblSMoneyHigh;
        private System.Windows.Forms.TextBox txtSMoneyHigh;
        private System.Windows.Forms.Label lblSMoneyLow;
        private System.Windows.Forms.TextBox txtSMoneyLow;
        private System.Windows.Forms.RadioButton rdoSMoney4;
        private System.Windows.Forms.RadioButton rdoSMoney3;
        private System.Windows.Forms.RadioButton rdoSMoney2;
        private System.Windows.Forms.RadioButton rdoSMoney1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblSRate;
        private System.Windows.Forms.Label lblSMoney;
        private System.Windows.Forms.Label lblSTime;
        private System.Windows.Forms.GroupBox grpSTime;
        private System.Windows.Forms.Label lblSTimeHigh;
        private System.Windows.Forms.TextBox txtSTimeHigh;
        private System.Windows.Forms.Label lblSTimeLow;
        private System.Windows.Forms.TextBox txtSTimeLow;
        private System.Windows.Forms.RadioButton rdoSTime4;
        private System.Windows.Forms.RadioButton rdoSTime3;
        private System.Windows.Forms.RadioButton rdoSTime2;
        private System.Windows.Forms.RadioButton rdoSTime1;
        private System.Windows.Forms.GroupBox grpSort;
        private System.Windows.Forms.RadioButton rdoSortRate;
        private System.Windows.Forms.RadioButton rdoSortMoney;
        private System.Windows.Forms.RadioButton rdoSortTime;
        private System.Windows.Forms.RadioButton rdoSortDefault;
        private System.Windows.Forms.GroupBox grpSortMode;
        private System.Windows.Forms.RadioButton rdoSortDown;
        private System.Windows.Forms.RadioButton rdoSortUp;
        private System.Windows.Forms.TabControl tabSelectModule;
        public System.Windows.Forms.Label lblShowPg;
        private System.Windows.Forms.RadioButton rdoMoneyAll;
        private System.Windows.Forms.RadioButton rdoTimeAll;
        private System.Windows.Forms.RadioButton rdoRateAll;
        private System.Windows.Forms.Button btnRConfirm;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMoney;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Other;
    }
}

