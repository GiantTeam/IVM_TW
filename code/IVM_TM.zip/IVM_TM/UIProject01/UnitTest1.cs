﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UIProject01
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
